Drop your dialogue characters here!

For more info on how this stuff works, go here:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Dialogues