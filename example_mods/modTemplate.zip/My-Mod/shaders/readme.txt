Drop your shader's .frag and .vert files here!
Both files are optional, if one of them are missing, it will use a default string instead of trying to load an unexistent file.